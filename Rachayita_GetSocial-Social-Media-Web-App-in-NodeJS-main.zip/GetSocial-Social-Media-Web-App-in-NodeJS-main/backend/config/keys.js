// const mongoose = require('mongoose');
// dbPassword = 'mongodb+srv://ExploreSphere:iOULWLSfnnz6W3i5@exploresphere.tv5f9g9.mongodb.net/e-commerce?retryWrites=true&w=majority&appName=ExploreSphere';

// module.exports = {
//     mongoURI: dbPassword
// };
// AT775PHUNVdaYnaU
//mondalasit0143
dbPassword = 'mongodb://localhost:27017/e-commerce';
module.exports = {
    mongoURI: dbPassword
};